package 팀과제.팀과제4.인터페이스구현;

public class Assasin implements User {

    @Override
    public void attack() {
        System.out.println("도적 : 럭키세븐 발사");
    }
}
