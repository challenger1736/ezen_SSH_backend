package 팀과제.팀과제4.클래스상속;

public class Archor extends Newbe {

    @Override
    public void attack() {
        System.out.println("궁수 : 더블 에로우 발사");
    }
}
